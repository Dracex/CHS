<?php
// Receive the data object from the client and append it to oferta1314.json if an equivalent entry doesn't exists yet.
// Use ID_centre and clau_cicle to check if an entry would be duplicated.
// Return a message to the client indicating the result of the operation.

?>